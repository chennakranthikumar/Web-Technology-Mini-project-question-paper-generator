``		QUESTION  PAPER GENERATOR 


Prerequisites
	Xampp software application	 
	Notepad++
	chrome(or)firefox(or)other broswer

Installing
1.Install the Xampp server application and run the apache server and mysql
2.copy the code file to  C:\xampp\htdocs\ directory 
3.Now go to broswer and run type localhost\C:\xampp\htdocs\question-paper-generator\login.php in the broswer url
4.Thw broswer should show the login page.

THE GIT HUB LINK FOR THE CODE
https://github.com/chennakranthikumar/question-paper-generator.git

<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>

<?php
  	
if(empty($_POST['qid'])||empty($_POST['yname'])||empty($_POST['sub'])||empty($_POST['doq'])||
empty($_POST['sem'])||empty($_POST['mod'])||empty($_POST['br']))
{
	echo "<html";
	echo "<body>";
	
	echo "<h3 align='center'> Some credentials are missing</h3>";
	echo "<span style='color:red'>Please fill all the credentials</span>";
	echo "<br><button onclick='goBack()'>Go Back</button>";
	echo "<script>";
	echo "function goBack(){";
	echo "window.history.back()}";
	echo "</script>";
	echo "</body>";
	echo "</html>";
	exit;
}

else{  

	$qi=$yn=$do=$mo=$se=$su=$b=" ";
	
	$qi=$_POST['qid'];
	$yn=$_POST['yname'];
	$do=$_POST['doq'];
	$b=$_POST['br'];
	$mo=$_POST['mod'];
	$se=$_POST['sem'];
	$su=$_POST['sub'];

	
	$conn = mysqli_connect("localhost","root","","project");
	if(!$conn){
		die("connection failed :".mysqli_connect_error());
	}
	$re=" ";
	$ch="INSERT INTO addregister(quesid,yourques,difficulty,branch,module,
        semister,subject) 

	VALUES('".$qi."','".$yn."','".$do."','".$b."','".$mo."','".$se."'
        ,'".$su."')";
    
	if(!$conn){
		die("connection failed :".mysqli_connect_error());
	}
	
	
	
	if(mysqli_query($conn,$ch)){
		echo "<html>";
		echo "<body>";
		
		//echo "<h3 align='center'>Successfully stored  </h3>";
	 
		//echo "<br><a href='testing.html' target='login'>login</a>";
		echo "</body>";
		echo "</html>";
	}
	else{
		echo"Error :".mysqli_error($conn);
		echo "record not entered";
	}
	
	$conn->close();	
}
?> 
<?php    
 $qi=$yn=$do=$mo=$se=$su=$b=" ";
	
	$qi=$_POST['qid'];
	$yn=$_POST['yname'];
	$do=$_POST['doq'];
	$b=$_POST['br'];
	$mo=$_POST['mod'];
	$se=$_POST['sem'];
	$su=$_POST['sub'];
	

$username = $_SESSION['username'];



// Create connection
$conn = new mysqli("localhost", "root","","myDB");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

	$ch="INSERT INTO $username (quesid,yourques,difficulty,branch,module,
        semister,subject) 

	VALUES('".$qi."','".$yn."','".$do."','".$b."','".$mo."','".$se."'
        ,'".$su."')";
  
if(mysqli_query($conn,$ch)){
		echo "<html>";
		echo "<body>";
		
		echo "<h3 align='center'>Successfully stored  </h3>";
	 
		//echo "<br><a href='testing.html' target='login'>login</a>";
		echo "</body>";
		echo "</html>";
	}
	else{
		echo"Error :".mysqli_error($conn);
		echo "record not entered";
	}

$conn->close();
	?>

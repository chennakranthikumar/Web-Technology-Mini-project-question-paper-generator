<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
  $username=$_SESSION['username'];
?>
<html>
<head>
<title>left</title>
<style>
body {
  font-size: 120%;
  background-image:url("images.jpg");
}
#i15{
color:hotpink;
text-decoration:none;
font-family:aerial;
font-size:20px;
}
.th{
color:red;
font:bold;
font-family:sanserif;
font-size:20px;
}
a:hover:red;
</style>
</head>
<body >
<table border="0" width="100%" align="center" cellspacing='3'>
<?php  echo "you entered as ".$username; ?>
<tr><td align="center" colspan="4" class=th  > MENU</td></tr>
<?php if ($username=='examcon')
{
echo '<tr><td align="center"><a href="createQues.php" target="right" id="i15">CreateQuestionPaper</td></tr>';
}
else
{
echo '<tr><td align="center"><a href="addqu.php" target="right" id="i15">AddQuestions</td></tr>';
echo '<tr><td align="center"><a href="showing.php" target="right" id="i15">ShowQuestions</td></tr>';
}
?>
<tr><td align="center">
<button type="submit"  style="background-color:palegreen">
   <a href="javascript://" onclick="self.parent.location='login.php'">Logout</a>


</html>
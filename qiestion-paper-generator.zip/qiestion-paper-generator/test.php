<?php 
$to_email="'krathi771@gmail.com';
@subject='Testing Mail";
$messsage='This mailis sent using thr php mail function';
$headers='From: noreplay@company.com';
mail($to_email,$subject,$message,$headers);?>

<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
  $username = $_SESSION['username'];
?>
<html>
<head>
<title>Question Paper generator</title>
</head>
<body bgcolor="Yellow">
<form action="create.php" method="POST">
<fieldset>
<legend>Question Paper Generator</legend>
<?php echo "you enetred as ".$username; ?>

<table cellspacing="5" cellpadding="3">
	<th colspan="2" align="center">Create Question Paper</th>
	<tr><td>Paper of Branch:</td>
	<td align="center">
	<select name="br">
	<option value="it">IT</option>
	<option value="cse">CSE</option>
	<option value="eee">EEE</option>
	<option value="ece">ECE</option>
	</select></td></tr>
	<tr><td>Semester:</td>
	<td align="center">
	<select name="sem">
	<OPTION value="1" >1</OPTION> 
 	<OPTION value="2" >2</OPTION> 
 	<OPTION value="3" >3</OPTION>
	<OPTION value="4" >4</OPTION>
	<OPTION value="5" >5</OPTION> 
 	<OPTION value="6" >6</OPTION> 
 	<OPTION value="7" >7</OPTION>
	<OPTION value="8" >8</OPTION>
	</select></td></tr>
	<tr><td>Subject:</td>
	<td align="center"><select name="sub">
	<option>WT</option>
	<option>CN</option>
	<option>OOAD</option>
	<option>CGM</option>
	<option>WN</option>
	<option>CD</option>
	</select></td></tr>
	<tr><td>Difficulty Of Paper:</td>
	<td align="center"><select name="dif">
	<option>Easy</option>
	<option>Medium</option>
	<option>Hard</option>
	</select></td></tr>
	<!--
	<tr><td>No Of Modules:</td>
	<td align="center"><select name="mod">
	<option>1</option>
	<option>2</option>
	<option>3</option>
	<option>4</option>
	<option>5</option>
	</select></td></tr>
	<tr><td>Question Per Module:</td>
	<td align="center"><select name="qpm">
	<option>1</option>
	<option>2</option>
	</select></td></tr>     
	-->
	<tr><td>Name Of Question Paper:</td>
	<td align="center"><input type="text" name="qname" size="15"></tr>
	<tr><td>Question Paper Code:</td>
	<td align="center"><input type="text" name="qcode" size="15"></tr>
<!--
	<tr><td>Marks Per Module:</td>
	<td align="center"><input type="text" name="marks" size="15"></tr>
	<tr><td>Choice Per Module:</td>
	<td align="center"><input type="text" name="choice" size="15"></tr>
-->
	<tr><td>Time For Exam:</td>
	<td align="center"><select name="time">
	<option>1/2</option>
	<option>1</option>
	<option>1 1/2</option>
	<option>2</option>
	<option>2 1/2</option>
	<option>3</option>
	</select></td></tr>
	<tr><td align="center" colspan="3"><input type="submit" value="Download" name="download"></td>
<!--	<td><input type="submit" value="Email" name="email">
<a href = 'mailto:my@email?body="Yourbody"&subject="a subject".com'></a>
-->

</table>
</form>
</fieldset>
</body>
</html>
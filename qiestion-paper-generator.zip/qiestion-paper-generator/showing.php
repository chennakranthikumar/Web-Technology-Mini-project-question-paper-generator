
<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
  $username = $_SESSION['username'];
?>
<html>
<head>
<title>right</title>
</head>
<body bgcolor="yellow">
<fieldset>
<legend> Question Paper generator</legend>
<?php echo "you are entered as ".$username ?>
<form action="showing.php" method="post">       
<table cellpadding="5" cellspacing="3">
<th colspan="2" align="center">Show Questions</th>

<tr><td>paper for branch</td>
<td align="center" >
<SELECT  name="br"> 
	<option value="it">IT</option>
	<option value="cse">CSE</option>
	<option value="eee">EEE</option>
	<option value="ece">ECE</option>
	</SELECT> 
</td></tr>
</tr>

<tr><td>semister</td>
<td align="center" >
<SELECT name="sem"> 
	<OPTION value="1" >1</OPTION> 
 	<OPTION value="2" >2</OPTION> 
 	<OPTION value="3" >3</OPTION>
	<OPTION value="4" >4</OPTION>
	<OPTION value="5" >5</OPTION> 
 	<OPTION value="6" >6</OPTION> 
 	<OPTION value="7" >7</OPTION>
	<OPTION value="8" >8</OPTION>
</SELECT> 
</td>
</tr>
<tr><td>subject</td>
<td align="center" >
<SELECT name="sub"> 
	<option>WT</option>
	<option>CN</option>
	<option>OOAD</option>
	<option>CGM</option>
	<option>WN</option>
	<option>CD</option>
</SELECT> 
</td>
</tr>                   
<tr><td align="center">
<input type="submit" value="show" name="show" >
</input>         
</td></tr>
</table>
</form>
</fieldset>

<?php
/*
if(isset($_POST['show']))
{
	$bran=$_POST['br'];
	$sems=$_POST['sem'];
	$subj=$_POST['sub'];
	$con=new mysqli("localhost","root","","project");
	$sql="SELECT * from addregister where branch='$bran' AND semister='$sems'";
	$result=$con->query($sql);
	if($result->num_rows>0)
	{
		echo"<table border='1'><tr><th>Sno</th><th>your que</th><th>branch</th><th>semister</th></tr>";
		$sno=0;
		while($row=$result->fetch_assoc())
		{
			$sno=$sno+1;
			echo"<tr><td>".$sno."</td><td>".$row['yourques']."</td><td>".$row['branch']."</td><td>".$row['semister']."</td></tr>";
		}
	}	
	else
		echo "no records";
	$con->close();
}
*/
?>



<?php
if(isset($_POST['show']))
{
	$bran=$_POST['br'];
	$sems=$_POST['sem'];
	$subj=$_POST['sub'];
	$con=new mysqli("localhost","root","","myDB");
	$sql="SELECT * from $username where branch='$bran' AND semister='$sems'";
	$result=$con->query($sql);
	if($result->num_rows>0)
	{
		echo"<table border='1'><tr><th>Sno</th><th>your que</th><th>branch</th><th>semister</th></tr>";
		$sno=0;
		while($row=$result->fetch_assoc())
		{
			$sno=$sno+1;
			echo"<tr><td>".$sno."</td><td>".$row['yourques']."</td><td>".$row['branch']."</td><td>".$row['semister']."</td></tr>";
		}
	}	
	else
		echo "no records";
	$con->close();
}
?>
</body>
</html>
<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>question paper generator</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php
          	echo $_SESSION['success'];
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>question paper generator <strong><?php echo $_SESSION['username']; ?></strong></p>
		
    	<p> <a href="index.php?logout='1'" style="color: red;">login</a> </p>
    <?php endif ?>
</div>
<?php

$username = $_SESSION['username'];



// Create connection
$conn = new mysqli("localhost", "root","","myDB");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE $username (
quesid INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
yourques text ,
difficulty VARCHAR(10) NOT NULL,
branch VARCHAR(10),
module int(2),
semister int(4),
subject varchar(15)
)";

if ($conn->query($sql) === TRUE) {
    echo "username of $username is sucessfully registered please log in with ur credits";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>

</body>
</html>

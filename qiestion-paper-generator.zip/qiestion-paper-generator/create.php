<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
  $username = $_SESSION['username'];
?>

<?php


// echo "u entered as ".$username;
if(isset($_POST['download']))
{
	$bran=$_POST['br'];
	$sems=$_POST['sem'];
	$subj=$_POST['sub'];
//	$modu=$_POST['mod'];
	$dif=$_POST['dif'];
//	$qpm=$_POST['qpm'];
	$qname=$_POST['qname'];
	$qcode=$_POST['qcode'];
//	$marks=$_POST['marks'];
//	$choice=$_POST['choice'];
	$time=$_POST['time'];
	
	$conn = new mysqli("localhost", "root","","myDB");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 $datalist=array();
 $showTable="SHOW TABLES FROM myDB";
 $getdata=mysqli_query($conn,$showTable);
 while($row=mysqli_fetch_row($getdata)){
 $datalist[]=$row;
 }
 
	$datalist=array_reduce($datalist,'array_merge',array());
//	bold=$(tput bold);
//	normal=$(tput sgr0);
	
	echo"                      SREE VIDYANIKETAN ENGINEERING COLLEGE \n";
	echo"                                   (AUTONOMOUS)    \n  " ; 
	echo"                       SREE SAINATH NAGAR,A.RANGAMPET-517102. \n";
	echo"                                   \n\n";
	echo "                               BRANCH:- ".$bran."\n\n" ;
	echo "                          QUATION PAPER CODE:- $qcode  \n";
	echo "                                                                     TIME:-".$time."\n\n";
	echo " ANSWER ALL THE QUESTIONS  :-\n\n";
//	echo " CHOICE PER MODULE:- $choice \n\n";	
 	$sno=0;
 foreach ($datalist as $name)
 {
//	 echo $name."\n";
	 	
	$con=new mysqli("localhost","root","","myDB");
	$sql="SELECT * from $name where branch='$bran' AND semister='$sems' AND difficulty='$dif' ";
	$result=$con->query($sql);                 
	if($result->num_rows>0)
	{
		
	
		while($row=$result->fetch_assoc())
		{
			$sno=$sno+1;
			echo " ".$sno. " " .$row['yourques']."\n";
		}
		
	}	
	
	$con->close();
 }
 	$file = "$qname.txt";
	$txt = fopen($file, "w") or die("Unable to open file!");
	fwrite($txt,"");
	fclose($txt);

	header('Content-Description: File Transfer');
	header('Content-Disposition: attachment; filename='.basename($file));
	header('Expires: 0');
	header('Cache-Control: must-revalidate');
	header('Pragma: public');
	header('Content-Length: ' . filesize($file));
	header("Content-Type: text/plain");
	
	readfile($file);

 $conn->close();
}
?>
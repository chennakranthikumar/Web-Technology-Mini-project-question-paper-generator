<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<html>
<head>
<title> Add question </title>

</head>
<body bgcolor="Yellow">
<?php echo "you are entered as ". $_SESSION['username']; ?>
<form action="storing.php" method="post">
<fieldset>
<legend>Question Paper Generator</legend>
<table cellspacing="5" cellpadding="3">
<th colspan="2" align="center">Add  Questions</th>
<tr><td>Question Id:</td>
<td align="center">
<input type="text" name="qid" id="qname" onblur="qname08()" size="20" >
<span id="one" style="color:red;"></span></td></tr>
<tr><td  >Your Question:</td>
<td align="center"><input type="text" name="yname" id="yname"size="20"
 onblur="yname08()"><span id="two" style="color:red;"></span></td></tr>
<tr><td >Difficulty of Question:</td>
<td align="center">
<SELECT name="doq"> 
	<OPTION value="easy">easy</OPTION> 
 	<OPTION value="medium">medium</OPTION> 
 	<OPTION value="difficult">difficult</OPTION> 
</SELECT> </td></tr>
<tr><td  >Branch:</td>
<td align="center" ><SELECT  name="br"> 
	<option value="it">IT</option>
	<option value="cse">CSE</option>
	<option value="eee">EEE</option>
	<option value="ece">ECE</option>
	</SELECT> 
</td></tr>
<tr><td  >Module:</td>
<td align="center">
	<SELECT name="mod"> 
	<option>1</option>
	<option>2</option>
	<option>3</option>
	<option>4</option>
	<option>5</option>
	</SELECT> 
</td></tr>
<tr><td   >Semister:</td>
<td align="center" >
<SELECT name="sem"> 
	<OPTION value="1" >1</OPTION> 
 	<OPTION value="2" >2</OPTION> 
 	<OPTION value="3" >3</OPTION>
	<OPTION value="4" >4</OPTION>
	<OPTION value="5" >5</OPTION> 
 	<OPTION value="6" >6</OPTION> 
 	<OPTION value="7" >7</OPTION>
	<OPTION value="8" >8</OPTION>
	</SELECT> 
</td></tr>
<tr><td   >Subject:</td>
<td align="center" >
<SELECT name="sub"> 
	<option>WT</option>
	<option>CN</option>
	<option>OOAD</option>
	<option>CGM</option>
	<option>WN</option>
	<option>CD</option> 
	</SELECT> 
</td></tr>

<td align="center"><input type="submit" value="SUBMIT" name="submit"></td></tr>
</table>
</form>
</fieldset>
</body>
</html>
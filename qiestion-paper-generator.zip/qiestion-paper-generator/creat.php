<html>
<head>
<title> CREATE QUESTION PAPER </title>
</head>
<frameset rows ="20%,*">
<frame src="top.php"name="top">
<frameset cols="20%,*">
<frame src="left.php"name="left">
<frame src="right.html"name="right">
</frameset>
</frameset>
<body>
</body>
</html>